package com.infosys.infymarket.user.dto;

import com.infosys.infymarket.user.entity.Cart;

public class CartDTO {

	String buyerid;
	ProductDTO prodid;
	int quantity;

	public String getBuyerid() {
		return buyerid;
	}

	public void setBuyerid(String buyerid) {
		this.buyerid = buyerid;
	}

	public ProductDTO getProdid() {
		return prodid;
	}

	public void setProdid(ProductDTO prodid) {
		this.prodid = prodid;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "CartDTO [buyerid=" + buyerid + ", prodid=" + prodid + ", quantity=" + quantity + "]";
	}

	public static CartDTO valueOf(Cart cart) {
		CartDTO cartDTO = new CartDTO();
		cartDTO.setBuyerid(cart.getBuyerid());
		ProductDTO productDTO = new ProductDTO();
		productDTO.setProdid(cart.getProdid());
		cartDTO.setProdid(productDTO);
		cartDTO.setQuantity(cart.getQuantity());
		return cartDTO;
	}
	public Cart createEntity() {
		Cart cart = new Cart();
		cart.setBuyerid(this.getBuyerid());
		cart.setProdid(this.getProdid().prodid);
		cart.setQuantity(this.getQuantity());
		return cart;
		
	}
}
