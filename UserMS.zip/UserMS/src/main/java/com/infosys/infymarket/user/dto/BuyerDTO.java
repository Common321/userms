package com.infosys.infymarket.user.dto;

import com.infosys.infymarket.user.entity.Buyer;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class BuyerDTO {
   
	Integer buyerid;
	@NotNull(message = "Please provide buyer name")
    @Pattern(regexp="^[^\s]+[-a-zA-Z\s]+([-a-zA-Z]+)*$", message="Name should contain only alphabets and space")
	String name;
	@Email(message = "Please provide valid email address")
    @NotNull(message = "Please provide email address")
	String email;
	@NotNull(message = "Please provide buyer phoneNo")
    @Pattern(regexp="^[789][0-9]{9}$", message="phoneNo should contain only digits")
	long phoneno;
	
	@NotNull(message = "Please provide buyer password")
    @Pattern(regexp="^(?=.[0-9])(?=.[a-z])(?=.[A-Z])(?=! @, #, $, %, ^, &, *).{7,20}$",
    message="Password should contain only alphabets,special characters and digits")
	String password;
	boolean isactive;
	boolean isprivileged;
	Integer rewardpoints;

	public long getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}
		public Integer getBuyerid() {
		return buyerid;
	}

	public void setBuyerid(Integer buyerid) {
		this.buyerid = buyerid;
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean getIsactive() {
		return isactive;
	}

	public void setIsactive(boolean b) {
		this.isactive = b;
	}

	public boolean getIsprivileged() {
		return isprivileged;
	}

	public void setIsprivileged(boolean b) {
		this.isprivileged = b;
	}

	public Integer getRewardpoints() {
		return rewardpoints;
	}

	public void setRewardpoints(Integer rewardpoints) {
		this.rewardpoints = rewardpoints;
	}
	

		@Override
	public String toString() {
		return "BuyerDTO [buyerid=" + buyerid + ", name=" + name + ", email=" + email + ", phoneno=" + phoneno
				+ ", password=" + password + ", isactive=" + isactive + ", isprivileged=" + isprivileged
				+ ", rewardpoints=" + rewardpoints + "]";
	}

		// Converts Entity into DTO
		public static BuyerDTO valueOf(Buyer buyer) {
			BuyerDTO buyerDTO = new BuyerDTO();
			buyerDTO.setBuyerid(buyer.getBuyerid());
			buyerDTO.setName(buyer.getName());
			buyerDTO.setEmail(buyer.getEmail());
			buyerDTO.setPhoneno(buyer.getPhoneno());
			buyerDTO.setPassword(buyer.getPassword());
			buyerDTO.setIsactive(buyer.getIsactive());
			buyerDTO.setIsprivileged(buyer.getIsprivileged());
			buyerDTO.setRewardpoints(buyer.getRewardpoints());
			return buyerDTO;
		}
		public Buyer createBuyer() {
            Buyer buyer = new Buyer();
          //  buyer.setBuyerid(this.getBuyerid());
            buyer.setName(this.getName());
            buyer.setPhoneno(this.getPhoneno());
            buyer.setEmail(this.getEmail());
            buyer.setPassword(this.getPassword());
            buyer.setIsprivileged(false);
            buyer.setRewardpoints(0);
            buyer.setIsactive(false);
            return buyer;
        }

}
